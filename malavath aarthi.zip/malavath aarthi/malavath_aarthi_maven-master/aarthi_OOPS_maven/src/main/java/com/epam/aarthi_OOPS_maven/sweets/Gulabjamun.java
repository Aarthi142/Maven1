package com.epam.aarthi_OOPS_maven.sweets;

public class Gulabjamun extends Sweets {

    public Gulabjamun(String name, int price, int weight) {
        super(name, price, weight);
    }
}